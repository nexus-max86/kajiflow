import { useState } from 'react';
import './styles.css';

const bordereauUrl = import.meta.env.VITE_N8N_BORDEREAU_URL;
const releveUrl = import.meta.env.VITE_N8N_RELEVE_URL;

function UploadForm({ title, accept, url }) {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(event) {
    event.preventDefault();
    if (!file) return setMessage('Sélectionne un fichier.');
    setLoading(true);
    setMessage('Envoi en cours…');
    try {
      const body = new FormData();
      body.append('file', file);
      const response = await fetch(url, { method: 'POST', body });
      const text = await response.text();
      if (!response.ok) throw new Error(`Erreur ${response.status}: ${text}`);
      setMessage('Envoi réussi.');
    } catch (error) {
      setMessage(error.message || 'Échec de l’envoi.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="card">
      <h2>{title}</h2>
      <input type="file" accept={accept} onChange={(e) => setFile(e.target.files?.[0] || null)} />
      <button disabled={loading}>{loading ? 'Envoi…' : 'Envoyer'}</button>
      <p>{message}</p>
    </form>
  );
}

export default function App() {
  return <main><h1>Kajiflow</h1><p>Gestion des bordereaux et matching bancaire</p><UploadForm title="Envoyer un bordereau" accept="image/*" url={bordereauUrl} /><UploadForm title="Envoyer un relevé" accept=".xlsx,.xls,.csv" url={releveUrl} /></main>;
}
