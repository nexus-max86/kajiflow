# Kajiflow — modèle Vercel

## Installation locale

```bash
cp .env.example .env
npm install
npm run dev
```

## Publication Vercel

1. Importer ce dossier dans GitHub.
2. Dans Vercel, choisir **Add New Project** puis le dépôt.
3. Framework : **Vite**.
4. Build command : `npm run build`.
5. Output directory : `dist`.
6. Reprendre les variables de `.env.example` dans **Settings → Environment Variables**.
7. Cliquer sur **Deploy**.

Ce modèle est une base de départ ; il ne contient pas automatiquement les écrans privés, l’authentification ou les données du site Manus original.
